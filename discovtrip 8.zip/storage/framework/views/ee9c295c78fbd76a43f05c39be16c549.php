<?php $__env->startSection('title', 'DiscovTrip — Découvrez le Bénin Authentique & Premium'); ?>


<?php $__env->startPush('meta'); ?>
<meta name="description" content="Réservez des expériences uniques au Bénin. Culture, nature, gastronomie — guidé par des experts locaux qui connaissent chaque secret du pays.">
<meta property="og:title" content="DiscovTrip — L'Afrique Authentique">
<meta property="og:description" content="Expériences premium au Bénin conçues par des experts locaux.">
<meta property="og:type" content="website">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta property="og:image" content="<?php echo e(asset('images/og-default.jpg')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/pages/home.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<section class="hp-hero" aria-label="Bannière principale">

    <div class="hp-hero-bg" aria-hidden="true">
        <img id="dt-hero-img"
             src="<?php echo e(asset('images/hero.jpg')); ?>"
             alt=""
             class="hp-hero-img"
             loading="eager"
             fetchpriority="high"
             decoding="async"
             width="1920" height="1080">
        <div class="hp-hero-overlay"></div>
        <div class="hp-hero-grain"></div>
    </div>

    <div class="hp-hero-content dt-container">

        <p class="hp-hero-eyebrow">
            <span class="hp-hero-eyebrow-dot" aria-hidden="true"></span>
            Bénin · Afrique de l'Ouest
        </p>

        <h1 class="hp-hero-title">
            L'Afrique<br>
            <em class="hp-hero-title-accent">authentique</em><br>
            vous attend
        </h1>

        <p class="hp-hero-sub">
            Expériences premium au cœur du Bénin.
            Guidé par des experts locaux, chaque voyage devient une mémoire inoubliable.
        </p>

        <div class="hp-search" role="search" aria-label="Rechercher une expérience">
            <form action="<?php echo e(route('offers.index')); ?>" method="GET" class="hp-search-form">
                <div class="hp-search-field">
                    <label for="hs-city" class="hp-search-label">Destination</label>
                    <select id="hs-city" name="city" class="hp-search-select">
                        <option value="">Toutes les villes</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $featuredCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="hp-search-sep" aria-hidden="true"></div>
                <div class="hp-search-field">
                    <label for="hs-category" class="hp-search-label">Type d'expérience</label>
                    <select id="hs-category" name="category" class="hp-search-select">
                        <option value="">Toutes les catégories</option>
                        <option value="culture">Culture &amp; Histoire</option>
                        <option value="nature">Nature &amp; Aventure</option>
                        <option value="gastronomie">Gastronomie</option>
                        <option value="plage">Plage &amp; Détente</option>
                        <option value="spiritualite">Spiritualité</option>
                        <option value="artisanat">Artisanat &amp; Art</option>
                    </select>
                </div>
                <button type="submit" class="hp-search-btn" aria-label="Lancer la recherche">
                    <i class="fas fa-search" aria-hidden="true"></i>
                    <span>Rechercher</span>
                </button>
            </form>
        </div>

        <div class="hp-hero-trust" aria-label="Garanties DiscovTrip">
            <div class="hp-trust-item"><i class="fas fa-star" aria-hidden="true"></i> 4.9 / 5 satisfaction</div>
            <span class="hp-trust-sep" aria-hidden="true"></span>
            <div class="hp-trust-item"><i class="fas fa-shield-alt" aria-hidden="true"></i> Paiement sécurisé</div>
            <span class="hp-trust-sep" aria-hidden="true"></span>
            <div class="hp-trust-item"><i class="fas fa-undo-alt" aria-hidden="true"></i> Annulation gratuite</div>
        </div>

    </div>

    <div class="hp-scroll-hint" aria-hidden="true">
        <div class="hp-scroll-hint-line"></div>
        <span class="hp-scroll-hint-label">Découvrir</span>
    </div>

</section>


<section class="hp-stats" aria-label="Chiffres clés DiscovTrip">
    <div class="hp-stats-inner dt-container">
        <div class="hp-stat-item dt-reveal dt-delay-1">
            <div class="hp-stat-icon" aria-hidden="true"><i class="fas fa-users"></i></div>
            <div class="hp-stat-num-wrap">
                <span class="hp-stat-num" data-target="500">0</span>
                <span class="hp-stat-suffix" aria-hidden="true">+</span>
            </div>
            <p class="hp-stat-label">Voyageurs satisfaits</p>
        </div>
        <div class="hp-stat-sep" aria-hidden="true"></div>
        <div class="hp-stat-item dt-reveal dt-delay-2">
            <div class="hp-stat-icon" aria-hidden="true"><i class="fas fa-compass"></i></div>
            <div class="hp-stat-num-wrap">
                <span class="hp-stat-num" data-target="<?php echo e($totalOffers); ?>">0</span>
            </div>
            <p class="hp-stat-label">Expériences uniques</p>
        </div>
        <div class="hp-stat-sep" aria-hidden="true"></div>
        <div class="hp-stat-item dt-reveal dt-delay-3">
            <div class="hp-stat-icon" aria-hidden="true"><i class="fas fa-map-marked-alt"></i></div>
            <div class="hp-stat-num-wrap">
                <span class="hp-stat-num" data-target="<?php echo e($totalCities); ?>">0</span>
            </div>
            <p class="hp-stat-label">Destinations explorées</p>
        </div>
        <div class="hp-stat-sep" aria-hidden="true"></div>
        <div class="hp-stat-item dt-reveal dt-delay-4">
            <div class="hp-stat-icon" aria-hidden="true"><i class="fas fa-star"></i></div>
            <div class="hp-stat-num-wrap">
                <span class="hp-stat-num" data-target="100">0</span>
                <span class="hp-stat-suffix" aria-hidden="true">%</span>
            </div>
            <p class="hp-stat-label">Guides locaux certifiés</p>
        </div>
    </div>
</section>


<div class="hp-marquee" aria-hidden="true" role="presentation">
    <div class="hp-marquee-track">
        <?php $marqueeItems = ['Cotonou','Ouidah','Abomey','Ganvié','Grand-Popo','Natitingou','Porto-Novo','Parakou','Pendjari','Cové']; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = array_merge($marqueeItems, $marqueeItems); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <span class="hp-marquee-item"><?php echo e($item); ?></span>
            <span class="hp-marquee-dot">✦</span>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
</div>


<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight): ?>
<section class="hp-spotlight" aria-labelledby="hp-spotlight-title">
    <div class="hp-spotlight-inner dt-container">

        <div class="hp-spotlight-media dt-reveal">
            <div class="hp-spotlight-img-wrap">
                <img src="<?php echo e(asset('storage/' . $spotlight->image)); ?>"
                     alt="<?php echo e($spotlight->title); ?>"
                     class="hp-spotlight-img"
                     loading="lazy" decoding="async" width="600" height="750">
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->badge_text): ?>
            <div class="hp-spotlight-badge">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->badge_icon): ?>
                <div class="hp-spotlight-badge-icon" aria-hidden="true"><i class="fas <?php echo e($spotlight->badge_icon); ?>"></i></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <p class="hp-spotlight-badge-text"><?php echo e($spotlight->badge_text); ?></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="hp-spotlight-content dt-reveal dt-delay-2">
            <p class="hp-spotlight-eyebrow">
                <i class="fas fa-landmark" aria-hidden="true"></i>
                <?php echo e($spotlight->badge_text ?? 'Bénin · Culture & Histoire'); ?>

            </p>
            <h2 class="hp-spotlight-title" id="hp-spotlight-title">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->highlight_word && Str::contains($spotlight->title, $spotlight->highlight_word)): ?>
                    <?php echo str_replace(e($spotlight->highlight_word), '<em class="hp-spotlight-title-accent">'.e($spotlight->highlight_word).'</em>', e($spotlight->title)); ?>

                <?php else: ?>
                    <?php echo e($spotlight->title); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->subtitle): ?>
                <p class="hp-spotlight-subtitle"><?php echo e($spotlight->subtitle); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->description): ?>
                <p class="hp-spotlight-desc"><?php echo e($spotlight->description); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->stat1_value || $spotlight->stat2_value || $spotlight->stat3_value): ?>
            <div class="hp-spotlight-stats">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->stat1_value): ?>
                    <div class="hp-spot-stat">
                        <span class="hp-spot-stat-num"><?php echo e($spotlight->stat1_value); ?></span>
                        <span class="hp-spot-stat-lbl"><?php echo e($spotlight->stat1_label); ?></span>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->stat2_value): ?>
                    <div class="hp-spot-stat">
                        <span class="hp-spot-stat-num"><?php echo e($spotlight->stat2_value); ?></span>
                        <span class="hp-spot-stat-lbl"><?php echo e($spotlight->stat2_label); ?></span>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spotlight->stat3_value): ?>
                    <div class="hp-spot-stat">
                        <span class="hp-spot-stat-num"><?php echo e($spotlight->stat3_value); ?></span>
                        <span class="hp-spot-stat-lbl"><?php echo e($spotlight->stat3_label); ?></span>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

    </div>
    
</section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<section class="hp-offers" aria-labelledby="hp-offers-title">
    <div class="dt-container">
        <header class="hp-section-header">
            <div>
                <div class="hp-chip hp-chip--ambre"><i class="fas fa-compass" aria-hidden="true"></i> À la une</div>
                <h2 class="hp-section-title" id="hp-offers-title">
                    Nos expériences<br><span class="hp-gradient-ambre">incontournables</span>
                </h2>
            </div>
            <a href="<?php echo e(route('offers.index')); ?>" class="hp-view-all" aria-label="Voir toutes les expériences">
                Voir toutes les expériences <i class="fas fa-arrow-right" aria-hidden="true"></i>
            </a>
        </header>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($featuredOffers->isNotEmpty()): ?>
        <div class="hp-offers-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $featuredOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <article class="hp-ocard <?php echo e($index === 0 ? 'hp-ocard--featured' : ''); ?> dt-reveal dt-delay-<?php echo e(min($index + 1, 5)); ?>"
                     aria-label="<?php echo e($offer->title); ?>">
                <a href="<?php echo e(route('offers.show', $offer->slug)); ?>" class="hp-ocard-img-link" tabindex="-1" aria-hidden="true">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($offer->cover_image): ?>
                    <img src="<?php echo e(asset('storage/' . $offer->cover_image)); ?>"
                         alt="<?php echo e($offer->title); ?>" class="hp-ocard-img"
                         loading="<?php echo e($index === 0 ? 'eager' : 'lazy'); ?>" decoding="async"
                         width="<?php echo e($index === 0 ? '600' : '400'); ?>" height="<?php echo e($index === 0 ? '800' : '300'); ?>">
                    <?php else: ?>
                    <div class="hp-ocard-img hp-ocard-img--placeholder" aria-hidden="true">
                        <i class="fas fa-image"></i>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="hp-ocard-overlay" aria-hidden="true"></div>
                </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <button class="dt-wish-btn" data-wishlist-id="<?php echo e($offer->id); ?>"
                        aria-label="Ajouter <?php echo e($offer->title); ?> aux favoris"
                        aria-pressed="false" type="button">
                    <i class="far fa-heart" aria-hidden="true"></i>
                </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="hp-ocard-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($offer->category): ?>
                        <p class="hp-ocard-cat"><?php echo e($offer->category); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <h3 class="hp-ocard-title">
                        <a href="<?php echo e(route('offers.show', $offer->slug)); ?>"><?php echo e($offer->title); ?></a>
                    </h3>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($offer->city): ?>
                        <p class="hp-ocard-city">
                            <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                            <?php echo e($offer->city->name); ?>

                        </p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="hp-ocard-footer">
                        <div class="hp-ocard-price">
                            <?php echo e(number_format($offer->base_price, 0, ',', ' ')); ?>

                            <span class="hp-ocard-price-unit">FCFA / pers.</span>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($offer->reviews_count > 0): ?>
                        <div class="hp-ocard-rating"
                             aria-label="Note : <?php echo e(number_format($offer->reviews_avg_rating, 1)); ?> sur 5">
                            <i class="fas fa-star" aria-hidden="true"></i>
                            <?php echo e(number_format($offer->reviews_avg_rating, 1)); ?>

                            <span class="hp-ocard-rating-count">(<?php echo e($offer->reviews_count); ?>)</span>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <?php else: ?>
        <div class="hp-empty-state">
            <i class="fas fa-compass" aria-hidden="true"></i>
            <p>Les expériences arrivent bientôt. Revenez nous voir !</p>
            <a href="<?php echo e(route('offers.index')); ?>" class="dt-btn dt-btn--ambre">Explorer le catalogue</a>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</section>


<section class="hp-destinations" aria-labelledby="hp-dest-title">
    <div class="dt-container">
        <header class="hp-section-header">
            <div>
                <div class="hp-chip hp-chip--foret">
                    <i class="fas fa-map-marked-alt" aria-hidden="true"></i> Explorer
                </div>
                <h2 class="hp-section-title" id="hp-dest-title">
                    Choisissez votre<br><span class="hp-gradient-foret">destination</span>
                </h2>
            </div>
            <a href="<?php echo e(route('destinations')); ?>" class="hp-view-all hp-view-all--foret">
                Toutes les destinations <i class="fas fa-arrow-right" aria-hidden="true"></i>
            </a>
        </header>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($featuredCities->isNotEmpty()): ?>
        <div class="hp-dest-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $featuredCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <a href="<?php echo e(route('destinations.city', $city->slug)); ?>"
               class="hp-dest-card dt-reveal dt-delay-<?php echo e($index + 1); ?>"
               aria-label="<?php echo e($city->name); ?>, <?php echo e($city->offers_count); ?> <?php echo e($city->offers_count > 1 ? 'expériences' : 'expérience'); ?>">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($city->cover_image): ?>
                <img src="<?php echo e(asset('storage/' . $city->cover_image)); ?>"
                     alt="<?php echo e($city->name); ?>" class="hp-dest-img"
                     loading="lazy" decoding="async" width="400" height="533">
                <?php else: ?>
                <div class="hp-dest-img hp-dest-img--placeholder" aria-hidden="true">
                    <i class="fas fa-map-marked-alt"></i>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="hp-dest-overlay" aria-hidden="true"></div>
                <div class="hp-dest-body">
                    <h3 class="hp-dest-name"><?php echo e($city->name); ?></h3>
                    <p class="hp-dest-count">
                        <i class="fas fa-compass" aria-hidden="true"></i>
                        <?php echo e($city->offers_count); ?> <?php echo e($city->offers_count > 1 ? 'expériences' : 'expérience'); ?>

                    </p>
                </div>
            </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</section>


<section class="hp-why" aria-labelledby="hp-why-title">
    <div class="hp-why-bg" aria-hidden="true"></div>
    <div class="dt-container hp-why-inner">
        <header class="hp-section-header hp-section-header--centered">
            <div class="hp-chip hp-chip--inv"><i class="fas fa-heart" aria-hidden="true"></i> Notre promesse</div>
            <h2 class="hp-section-title hp-section-title--inv" id="hp-why-title">
                Pourquoi choisir<br><span class="hp-gradient-ambre">DiscovTrip</span> ?
            </h2>
            <p class="hp-why-sub">
                Une agence locale, une promesse mondiale.
                Chaque détail pensé pour votre confort et votre découverte.
            </p>
        </header>
        <?php
        $whyCards = [
            ['icon' => 'fa-map-marked-alt', 'color' => 'ambre',  'title' => 'Guides locaux certifiés',  'desc' => 'Des experts nés et formés au Bénin. Chaque guide connaît chaque sentier, chaque histoire, chaque saveur authentique de son territoire.'],
            ['icon' => 'fa-leaf',            'color' => 'foret',  'title' => 'Tourisme responsable',      'desc' => 'Nous investissons dans les communautés locales. Chaque réservation contribue directement aux familles d\'accueil et aux artisans.'],
            ['icon' => 'fa-shield-alt',      'color' => 'braise', 'title' => 'Sécurité & flexibilité',   'desc' => 'Annulation gratuite jusqu\'à 48h. Paiement sécurisé FedaPay & Stripe. Assistance locale 24/7 pendant tout votre séjour.'],
            ['icon' => 'fa-sliders-h',       'color' => 'ambre',  'title' => 'Expériences sur mesure',   'desc' => 'Durée, groupe, budget : chaque voyage s\'adapte à votre rythme. Nous personnalisons chaque détail pour une expérience unique.'],
        ];
        ?>
        <div class="hp-why-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $whyCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <div class="hp-why-card dt-reveal dt-delay-<?php echo e($index + 1); ?>">
                <div class="hp-why-icon hp-why-icon--<?php echo e($card['color']); ?>" aria-hidden="true">
                    <i class="fas <?php echo e($card['icon']); ?>"></i>
                </div>
                <h3 class="hp-why-card-title"><?php echo e($card['title']); ?></h3>
                <p class="hp-why-card-desc"><?php echo e($card['desc']); ?></p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
</section>


<section class="hp-process" aria-labelledby="hp-process-title">
    <div class="dt-container">
        <header class="hp-section-header hp-section-header--centered">
            <div class="hp-chip hp-chip--ambre">
                <i class="fas fa-route" aria-hidden="true"></i> Simple &amp; rapide
            </div>
            <h2 class="hp-section-title" id="hp-process-title">
                Réserver en <span class="hp-gradient-ambre">3 étapes</span>
            </h2>
        </header>
        <?php
        $steps = [
            ['num' => '01', 'icon' => 'fa-search',           'title' => 'Choisissez', 'desc' => 'Parcourez notre catalogue. Filtrez par destination, durée ou type d\'activité pour trouver l\'expérience qui vous correspond.'],
            ['num' => '02', 'icon' => 'fa-calendar-check',   'title' => 'Réservez',   'desc' => 'Sélectionnez votre date, le nombre de participants et payez en toute sécurité avec FedaPay ou Stripe.'],
            ['num' => '03', 'icon' => 'fa-suitcase-rolling', 'title' => 'Vivez',      'desc' => 'Votre guide vous accueille sur place. Il ne vous reste plus qu\'à savourer chaque instant de votre aventure.'],
        ];
        ?>
        <div class="hp-process-steps">
            <div class="hp-process-connector" aria-hidden="true"></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <div class="hp-process-step dt-reveal dt-delay-<?php echo e($index + 1); ?>">
                <div class="hp-step-badge" aria-hidden="true"><?php echo e($step['num']); ?></div>
                <div class="hp-step-icon-wrap" aria-hidden="true"><i class="fas <?php echo e($step['icon']); ?>"></i></div>
                <h3 class="hp-step-title"><?php echo e($step['title']); ?></h3>
                <p class="hp-step-desc"><?php echo e($step['desc']); ?></p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <div class="hp-process-cta dt-reveal">
            <a href="<?php echo e(route('offers.index')); ?>" class="dt-btn dt-btn--ambre">
                <i class="fas fa-compass" aria-hidden="true"></i> Explorer les expériences
            </a>
        </div>
    </div>
</section>


<section class="hp-testimonials" aria-labelledby="hp-testi-title">
    <div class="dt-container">
        <header class="hp-section-header">
            <div>
                <div class="hp-chip hp-chip--neutral">
                    <i class="fas fa-quote-left" aria-hidden="true"></i> Ils en parlent
                </div>
                <h2 class="hp-section-title" id="hp-testi-title">
                    Ce que disent<br>nos <span class="hp-gradient-ambre">voyageurs</span>
                </h2>
            </div>
        </header>

        <?php
        // Fallback statique si la table testimonials est vide
        $fallbackTestimonials = [
            ['text' => 'Une expérience qui m\'a profondément transformé. Les guides connaissent chaque secret de ce pays magnifique. Je reviendrai sans la moindre hésitation.', 'client_name' => 'Marie Dupont',   'client_title' => 'Paris, France',       'rating' => 5],
            ['text' => 'Ganvié, c\'est un autre monde. DiscovTrip nous a offert un accès privilégié à des lieux et des familles qu\'aucune agence classique ne peut proposer.',   'client_name' => 'Kofi Mensah',    'client_title' => 'Accra, Ghana',        'rating' => 5],
            ['text' => 'Organisation parfaite, guides passionnés, lieux extraordinaires. Le Bénin m\'a surpris au-delà de toutes mes attentes. Un grand merci à toute l\'équipe !', 'client_name' => 'Sophie Laurent', 'client_title' => 'Bruxelles, Belgique',  'rating' => 5],
        ];
        $colors  = ['ambre','foret','braise'];
        $useDB   = $testimonials->isNotEmpty();
        $items   = $useDB ? $testimonials : collect($fallbackTestimonials);
        ?>

        <div class="hp-testi-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <?php
                $text     = $useDB ? $t->testimonial : $t['text'];
                $name     = $useDB ? $t->client_name : $t['client_name'];
                $location = $useDB ? ($t->client_title ?? '') : $t['client_title'];
                $rating   = $useDB ? (int) $t->rating : $t['rating'];
                $initial  = strtoupper(substr($name, 0, 1));
                $color    = $colors[$index % 3];
            ?>
            <blockquote class="hp-testi-card dt-reveal dt-delay-<?php echo e($index + 1); ?>"
                        aria-label="Témoignage de <?php echo e($name); ?>">
                <div class="hp-testi-quote-mark" aria-hidden="true">"</div>
                <p class="hp-testi-text"><?php echo e($text); ?></p>
                <footer class="hp-testi-footer">
                    <div class="hp-testi-divider" aria-hidden="true"></div>
                    <div class="hp-testi-author">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($useDB && $t->client_photo): ?>
                        <div class="hp-testi-avatar hp-testi-avatar--<?php echo e($color); ?>" aria-hidden="true">
                            <img src="<?php echo e(asset('storage/' . $t->client_photo)); ?>"
                                 alt="<?php echo e($name); ?>"
                                 style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
                        </div>
                        <?php else: ?>
                        <div class="hp-testi-avatar hp-testi-avatar--<?php echo e($color); ?>" aria-hidden="true">
                            <?php echo e($initial); ?>

                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="hp-testi-author-info">
                            <cite class="hp-testi-name"><?php echo e($name); ?></cite>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($location): ?>
                            <p class="hp-testi-loc">
                                <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                                <?php echo e($location); ?>

                            </p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($useDB && $t->offer_title): ?>
                            <p class="hp-testi-loc" style="color:var(--a-500);font-weight:600;">
                                <i class="fas fa-ticket-alt" aria-hidden="true"></i>
                                <?php echo e($t->offer_title); ?>

                            </p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <div class="hp-testi-stars" aria-label="Note : <?php echo e($rating); ?> sur 5">
                                <?php
                                    $litStars = min((int)$rating, 5);
                                    echo str_repeat('<i class="fas fa-star" aria-hidden="true"></i>', $litStars);
                                ?>
                            </div>
                        </div>
                    </div>
                </footer>
            </blockquote>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
</section>


<section class="hp-newsletter" aria-labelledby="hp-newsletter-title">
    <div class="hp-newsletter-inner dt-container">
        <div class="hp-newsletter-text">
            <p class="hp-newsletter-eyebrow">Restez informé</p>
            <h2 class="hp-newsletter-title" id="hp-newsletter-title">
                Des expériences<br>rien que pour vous
            </h2>
            <p class="hp-newsletter-sub">
                Offres exclusives, nouvelles destinations, conseils de voyage — dans votre boîte mail.
                Pas de spam.
            </p>
        </div>
        <div class="hp-newsletter-form-wrap">
            <form class="hp-newsletter-form"
                  data-newsletter
                  action="<?php echo e(route('newsletter.subscribe')); ?>"
                  method="POST"
                  novalidate
                  aria-label="Formulaire newsletter">
                <?php echo csrf_field(); ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('newsletter_success')): ?>
                <div style="padding:12px 16px;background:rgba(42,143,94,.1);border:1.5px solid rgba(42,143,94,.25);border-radius:10px;font-size:.85rem;color:var(--f-600);margin-bottom:14px;display:flex;align-items:center;gap:8px;">
                    <i class="fas fa-check-circle"></i>
                    <?php echo e(session('newsletter_success')); ?>

                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="hp-newsletter-input-row">
                    <label for="nl-email" class="hp-newsletter-label">Votre adresse email</label>
                    <input type="email" id="nl-email" name="email"
                           class="hp-newsletter-input"
                           placeholder="votre@email.com"
                           required autocomplete="email" inputmode="email">
                    <button type="submit" class="hp-newsletter-btn">
                        <i class="fas fa-paper-plane" aria-hidden="true"></i>
                        <span>S'inscrire</span>
                    </button>
                </div>
                <p class="hp-newsletter-privacy">
                    <i class="fas fa-lock" aria-hidden="true"></i>
                    Données protégées — désabonnement en 1 clic
                </p>
            </form>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    'use strict';

    /* ── Counter animation ── */
    function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
    function runCounter(el) {
        var target = parseInt(el.getAttribute('data-target'), 10);
        var start  = null;
        (function tick(ts) {
            if (!start) start = ts;
            var p = Math.min((ts - start) / 1800, 1);
            el.textContent = Math.floor(easeOutCubic(p) * target);
            if (p < 1) requestAnimationFrame(tick);
            else el.textContent = target;
        }(performance.now()));
    }
    if ('IntersectionObserver' in window) {
        var co = new IntersectionObserver(function(entries) {
            entries.forEach(function(e) {
                if (e.isIntersecting && !e.target.dataset.done) {
                    e.target.dataset.done = '1';
                    runCounter(e.target);
                    co.unobserve(e.target);
                }
            });
        }, { threshold: 0.6 });
        document.querySelectorAll('.hp-stat-num[data-target]').forEach(function(el) {
            co.observe(el);
        });
    } else {
        document.querySelectorAll('.hp-stat-num[data-target]').forEach(function(el) {
            el.textContent = el.getAttribute('data-target');
        });
    }

    /* ── Parallaxe hero ── */
    var heroImg = document.getElementById('dt-hero-img');
    if (heroImg && window.matchMedia('(min-width: 1024px)').matches) {
        var ticking = false;
        window.addEventListener('scroll', function() {
            if (!ticking) {
                requestAnimationFrame(function() {
                    var sy = window.scrollY;
                    if (sy < window.innerHeight) {
                        heroImg.style.transform = 'translateY(' + (sy * 0.22) + 'px) scale(1.04)';
                    }
                    ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });
    }

    /* ── Select has-value ── */
    document.querySelectorAll('.hp-search-select').forEach(function(sel) {
        function sync() { sel.classList.toggle('hp-search-select--filled', sel.value !== ''); }
        sel.addEventListener('change', sync);
        sync();
    });

})();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Herd\discovtrip\resources\views/pages/home.blade.php ENDPATH**/ ?>