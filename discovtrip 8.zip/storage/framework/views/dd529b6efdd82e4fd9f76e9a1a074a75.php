<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token"                    content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-Frame-Options"         content="SAMEORIGIN">
    <meta http-equiv="X-Content-Type-Options"  content="nosniff">
    <meta name="referrer"                      content="strict-origin-when-cross-origin">

    
    <title><?php echo $__env->yieldContent('title', 'DiscovTrip — L\'Afrique Authentique & Premium'); ?></title>
    <meta name="description" content="<?php if (! empty(trim($__env->yieldContent('description')))): ?> <?php echo $__env->yieldContent('description'); ?> <?php else: ?> Réservez des expériences uniques au Bénin. Culture, nature, gastronomie — découvrez l'Afrique autrement avec DiscovTrip. <?php endif; ?>">
    <meta name="robots"    content="<?php echo $__env->yieldContent('robots', 'index, follow'); ?>">
    <link rel="canonical"  href="<?php echo e(url()->current()); ?>">

    
    <meta property="og:type"        content="website">
    <meta property="og:url"         content="<?php echo e(url()->current()); ?>">
    <meta property="og:site_name"   content="DiscovTrip">
    <meta property="og:locale"      content="fr_FR">
    <meta property="og:title"       content="<?php echo $__env->yieldContent('og_title',       'DiscovTrip — L\'Afrique Authentique'); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('og_description', 'Expériences premium au Bénin'); ?>">
    <meta property="og:image"       content="<?php echo $__env->yieldContent('og_image',       asset('images/og-default.jpg')); ?>">

    
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?php echo $__env->yieldContent('og_title',       'DiscovTrip — L\'Afrique Authentique'); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('og_description', 'Expériences premium au Bénin'); ?>">
    <meta name="twitter:image"       content="<?php echo $__env->yieldContent('og_image',       asset('images/og-default.jpg')); ?>">

    
    <meta name="geo.region"   content="BJ">
    <meta name="geo.placename"content="Cotonou">

    
    <link rel="icon"             href="<?php echo e(asset('favicon.ico')); ?>"                type="image/x-icon">
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/apple-touch-icon.png')); ?>">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" as="style"
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,700&family=Syne:wght@400;500;600;700;800&display=swap">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,700&family=Syne:wght@400;500;600;700;800&display=swap"
          rel="stylesheet">

    
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
          referrerpolicy="no-referrer">

    
    <script defer
            src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.3/dist/cdn.min.js"
            integrity="sha384-eSWQ+3f4MuGUL9/VcCDqAUh6bPjhvJhpSl0HiHJdH9c+kGhBwSmyAX7sFKzmKuG"
            crossorigin="anonymous"></script>

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    
    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <?php echo $__env->yieldPushContent('meta'); ?>

    
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "TravelAgency",
        "name": "DiscovTrip",
        "description": "Agence de tourisme premium au Bénin",
        "url": "<?php echo e(config('app.url')); ?>",
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "Cotonou",
            "addressCountry": "BJ"
        }
    }
    </script>
</head>


<body
    class="antialiased"
    x-data="{
        navOpen:     false,
        navScrolled: false,
        wishCount:   <?php echo e(auth()->check() ? (int) auth()->user()->wishlists()->count() : 0); ?>,
    }"
    @scroll.window="navScrolled = (window.scrollY > 40)">


<a href="#main-content" class="dt-skip-link">Aller au contenu principal</a>


<header role="banner">
<nav class="dt-nav"
     :class="{ 'dt-nav--scrolled': navScrolled }"
     aria-label="Navigation principale">

    <div class="dt-nav-inner">

        
        <a href="<?php echo e(route('home')); ?>"
           class="dt-logo"
           aria-label="DiscovTrip — Retour à l'accueil">
            <img src="<?php echo e(asset('images/logo.jpg')); ?>"
                 alt="DiscovTrip"
                 class="dt-logo-img"
                 width="44" height="44"
                 loading="eager">
            <div class="dt-logo-text">
                <span class="dt-logo-name">DiscovTrip</span>
                <span class="dt-logo-tagline">Authentic Africa · Bénin</span>
            </div>
        </a>

        
        <nav class="dt-nav-links" aria-label="Menu principal">
            <a href="<?php echo e(route('offers.index')); ?>"
               class="dt-nav-link <?php echo e(request()->routeIs('offers*') ? 'dt-nav-link--active' : ''); ?>">
                Expériences
            </a>
            <a href="<?php echo e(url('/destinations')); ?>"
               class="dt-nav-link <?php echo e(request()->is('destinations*') ? 'dt-nav-link--active' : ''); ?>">
                Destinations
            </a>
            <a href="<?php echo e(url('/about')); ?>"
               class="dt-nav-link <?php echo e(request()->is('about*') ? 'dt-nav-link--active' : ''); ?>">
                À propos
            </a>
            <a href="<?php echo e(url('/contact')); ?>"
               class="dt-nav-link <?php echo e(request()->is('contact*') ? 'dt-nav-link--active' : ''); ?>">
                Contact
            </a>
        </nav>

        
        <div class="dt-nav-auth">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('account.wishlist')); ?>"
               class="dt-nav-wishlist"
               title="Mes favoris"
               aria-label="Mes favoris (<?php echo e(auth()->user()->wishlists()->count()); ?>)">
                <i class="fas fa-heart" aria-hidden="true"></i>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->wishlists()->count() > 0): ?>
                    <span class="dt-nav-wishlist-badge" aria-hidden="true">
                        <?php echo e(auth()->user()->wishlists()->count()); ?>

                    </span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>"   class="dt-btn dt-btn--ghost-dark">Connexion</a>
                <a href="<?php echo e(route('register')); ?>" class="dt-btn dt-btn--ambre">
                    S'inscrire <i class="fas fa-arrow-right" aria-hidden="true"></i>
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('account.dashboard')); ?>" class="dt-nav-user">
                    <div class="dt-nav-avatar" aria-hidden="true">
                        <?php echo e(strtoupper(substr(Auth::user()->name ?? 'U', 0, 1))); ?>

                    </div>
                    <div class="dt-nav-user-info">
                        <span class="dt-nav-user-name"><?php echo e(Str::limit(Auth::user()->name ?? '', 18)); ?></span>
                        <span class="dt-nav-user-sub">Mon compte</span>
                    </div>
                </a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dt-btn-icon" title="Se déconnecter" aria-label="Se déconnecter">
                        <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                    </button>
                </form>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <button class="dt-hamburger"
                :class="{ 'dt-hamburger--open': navOpen }"
                @click="navOpen = !navOpen"
                :aria-expanded="navOpen.toString()"
                aria-controls="dt-mobile-menu"
                aria-label="Ouvrir le menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</nav>
</header>


<div class="dt-mobile-overlay"
     :class="{ 'dt-mobile-overlay--open': navOpen }"
     x-cloak
     @click="navOpen = false"
     aria-hidden="true"></div>


<div id="dt-mobile-menu"
     class="dt-mobile-menu"
     :class="{ 'dt-mobile-menu--open': navOpen }"
     x-cloak
     :aria-hidden="(!navOpen).toString()"
     role="dialog"
     aria-label="Menu mobile">

    <nav aria-label="Menu mobile" class="dt-mobile-nav">
        <?php
        $mobileLinks = [
            ['href' => route('offers.index'), 'label' => 'Expériences',  'icon' => 'fa-compass'],
            ['href' => url('/destinations'),   'label' => 'Destinations', 'icon' => 'fa-map-marked-alt'],
            ['href' => url('/about'),          'label' => 'À propos',     'icon' => 'fa-info-circle'],
            ['href' => url('/contact'),        'label' => 'Contact',      'icon' => 'fa-envelope'],
        ];
        ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $mobileLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <a href="<?php echo e($link['href']); ?>"
               class="dt-mobile-link"
               @click="navOpen = false">
                <i class="fas <?php echo e($link['icon']); ?> dt-mobile-link-icon" aria-hidden="true"></i>
                <?php echo e($link['label']); ?>

            </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </nav>

    <div class="dt-mobile-auth">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>"    class="dt-btn dt-btn--ghost-dark dt-btn--full">Connexion</a>
            <a href="<?php echo e(route('register')); ?>" class="dt-btn dt-btn--ambre    dt-btn--full">
                S'inscrire <i class="fas fa-arrow-right" aria-hidden="true"></i>
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('account.dashboard')); ?>" class="dt-mobile-user-card">
                <div class="dt-nav-avatar"><?php echo e(strtoupper(substr(Auth::user()->name ?? 'U', 0, 1))); ?></div>
                <div>
                    <div class="dt-mobile-user-name"><?php echo e(Auth::user()->name); ?></div>
                    <div class="dt-mobile-user-sub">Mon espace</div>
                </div>
            </a>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="dt-btn dt-btn--ghost-danger dt-btn--full">
                    <i class="fas fa-sign-out-alt" aria-hidden="true"></i> Déconnexion
                </button>
            </form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>


<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success') || session('error') || session('info') || session('warning')): ?>
<div class="dt-toast-stack"
     x-data="{ show: true }"
     x-show="show"
     x-cloak
     x-init="setTimeout(() => show = false, 6000)"
     x-transition:enter="dt-toast-enter"
     x-transition:enter-start="dt-toast-enter-start"
     x-transition:enter-end="dt-toast-enter-end"
     x-transition:leave="dt-toast-leave"
     x-transition:leave-start="dt-toast-leave-start"
     x-transition:leave-end="dt-toast-leave-end"
     aria-live="polite"
     aria-atomic="true">

    <?php
    $toasts = [
        'success' => ['icon' => 'fa-check-circle',         'label' => 'Succès',      'type' => 'success'],
        'error'   => ['icon' => 'fa-times-circle',          'label' => 'Erreur',      'type' => 'error'],
        'info'    => ['icon' => 'fa-info-circle',           'label' => 'Information', 'type' => 'info'],
        'warning' => ['icon' => 'fa-exclamation-triangle',  'label' => 'Attention',   'type' => 'warning'],
    ];
    ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $toasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session($key)): ?>
        <div class="dt-toast dt-toast--<?php echo e($cfg['type']); ?>" role="alert">
            <i class="fas <?php echo e($cfg['icon']); ?> dt-toast-icon" aria-hidden="true"></i>
            <div class="dt-toast-body">
                <p class="dt-toast-title"><?php echo e($cfg['label']); ?></p>
                <p class="dt-toast-msg"><?php echo e(session($key)); ?></p>
            </div>
            <button @click="show = false" class="dt-toast-close" aria-label="Fermer">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<main id="main-content" role="main" tabindex="-1" style="padding-top: var(--nav-h)">
    <?php echo $__env->yieldContent('content'); ?>
</main>


<footer class="dt-footer" aria-label="Pied de page">

    <div class="dt-footer-bar" aria-hidden="true"></div>

    <div class="dt-footer-inner">
        <div class="dt-footer-grid">

            
            <div class="dt-footer-brand">
                <a href="<?php echo e(route('home')); ?>" class="dt-footer-logo" aria-label="DiscovTrip — Accueil">
                    <img src="<?php echo e(asset('images/logo.jpg')); ?>"
                         alt="DiscovTrip"
                         class="dt-footer-logo-img"
                         width="36" height="36"
                         loading="lazy">
                    <span class="dt-footer-logo-name">DiscovTrip</span>
                </a>
                <p class="dt-footer-brand-desc">
                    L'Afrique authentique et premium à portée de clic.
                    Expériences inoubliables au Bénin, conçues par des experts locaux.
                </p>
                <div class="dt-footer-socials" aria-label="Réseaux sociaux">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                        ['icon' => 'fa-instagram',   'href' => 'https://www.instagram.com/discovtrip', 'label' => 'Instagram'],
                        ['icon' => 'fa-facebook-f',  'href' => 'https://www.facebook.com/discovtrip', 'label' => 'Facebook'],
                        ['icon' => 'fa-whatsapp',   'href' =>  'https://wa.me/2290XXXXXXXXX',           'label' => 'WhatsApp'],
                        ['icon' => 'fa-twitter',     'href' => '#', 'label' => 'Twitter / X'],
                        ['icon' => 'fa-linkedin-in', 'href' => '#', 'label' => 'LinkedIn'],
                        ['icon' => 'fa-youtube',     'href' => '#', 'label' => 'YouTube'],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <a href="<?php echo e($social['href']); ?>"
                           class="dt-footer-social"
                           aria-label="<?php echo e($social['label']); ?>"
                           rel="noopener noreferrer" target="_blank">
                            <i class="fab <?php echo e($social['icon']); ?>" aria-hidden="true"></i>
                        </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>

            
            <div>
                <h3 class="dt-footer-heading">Explorer</h3>
                <ul>
                    <li><a href="<?php echo e(route('offers.index')); ?>" class="dt-footer-link">Toutes les expériences</a></li>
                    <li><a href="<?php echo e(url('/destinations')); ?>"  class="dt-footer-link">Destinations</a></li>
                    <li><a href="<?php echo e(route('offers.index')); ?>" class="dt-footer-link">Offres spéciales</a></li>
                    <li><a href="<?php echo e(url('/about')); ?>"         class="dt-footer-link">Notre histoire</a></li>
                    <li><a href="<?php echo e(url('/contact')); ?>"       class="dt-footer-link">Contactez-nous</a></li>
                </ul>
            </div>

            
            <div>
                <h3 class="dt-footer-heading">Pratique</h3>
                <ul>
                    <li><a href="<?php echo e(route('account.dashboard')); ?>"                    class="dt-footer-link">Mon espace</a></li>
                    <li><a href="<?php echo e(route('account.bookings')); ?>"                     class="dt-footer-link">Mes réservations</a></li>
                    <li><a href="<?php echo e(route('account.wishlist')); ?>"                     class="dt-footer-link">Mes favoris</a></li>
                    <li><a href="<?php echo e(url('/conditions-utilisation')); ?>"                class="dt-footer-link">Conditions d'utilisation</a></li>
                    <li><a href="<?php echo e(url('/confidentialite')); ?>"                       class="dt-footer-link">Confidentialité</a></li>
                    <li><a href="<?php echo e(url('/cancellation')); ?>"                          class="dt-footer-link">Annulation gratuite</a></li>
                    <li><a href="<?php echo e(url('/faq')); ?>"                                   class="dt-footer-link">FAQ</a></li>
                </ul>
            </div>

            
            <div>
                <h3 class="dt-footer-heading">Contact</h3>
                <div class="dt-footer-contacts">
                    <div class="dt-footer-contact-row">
                        <div class="dt-footer-contact-ico dt-footer-contact-ico--ambre">
                            <i class="fas fa-envelope" aria-hidden="true"></i>
                        </div>
                        <div>
                            <p class="dt-footer-contact-label">Email</p>
                            <a href="mailto:hello@discovtrip.com" class="dt-footer-contact-value">
                                hello@discovtrip.com
                            </a>
                        </div>
                    </div>
                    <div class="dt-footer-contact-row">
                        <div class="dt-footer-contact-ico dt-footer-contact-ico--foret">
                            <i class="fas fa-phone" aria-hidden="true"></i>
                        </div>
                        <div>
                            <p class="dt-footer-contact-label">Téléphone</p>
                            <a href="tel:+2290100000000" class="dt-footer-contact-value">+229 XX XX XX XX XX</a>
                        </div>
                    </div>
                    <div class="dt-footer-contact-row">
                        <div class="dt-footer-contact-ico dt-footer-contact-ico--braise">
                            <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                        </div>
                        <div>
                            <p class="dt-footer-contact-label">Localisation</p>
                            <span class="dt-footer-contact-value">Cotonou, Bénin 🇧🇯</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        
        <div class="dt-footer-bottom">
            <p class="dt-footer-copy">
                &copy; <?php echo e(date('Y')); ?> <strong>DiscovTrip</strong>.
                Fait avec <i class="fas fa-heart" aria-hidden="true"></i> au Bénin.
                Tous droits réservés.
            </p>
            <div class="dt-footer-trust" aria-label="Garanties">
                <div class="dt-footer-trust-item">
                    <i class="fas fa-shield-alt dt-footer-trust-item--foret" aria-hidden="true"></i>
                    <span>Paiement sécurisé</span>
                </div>
                <div class="dt-footer-trust-item">
                    <i class="fas fa-headset dt-footer-trust-item--ambre" aria-hidden="true"></i>
                    <span>Support 24/7</span>
                </div>
                <div class="dt-footer-trust-item">
                    <i class="fas fa-undo-alt dt-footer-trust-item--foret" aria-hidden="true"></i>
                    <span>Annulation gratuite</span>
                </div>
            </div>
        </div>
    </div>
</footer>


<?php echo $__env->yieldPushContent('scripts'); ?>

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
(function () {
    'use strict';

    /* ── Scroll Reveal ── */
    if ('IntersectionObserver' in window) {
        var revealObs = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (e.isIntersecting) {
                    e.target.classList.add('dt-reveal--in');
                    revealObs.unobserve(e.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -48px 0px' });

        document.querySelectorAll('.dt-reveal, .dt-reveal-left, .dt-reveal-right').forEach(function (el) {
            revealObs.observe(el);
        });
    } else {
        document.querySelectorAll('.dt-reveal, .dt-reveal-left, .dt-reveal-right').forEach(function (el) {
            el.classList.add('dt-reveal--in');
        });
    }

    /* ── Hero image loaded ── */
    var heroImg = document.getElementById('dt-hero-img');
    if (heroImg) {
        if (heroImg.complete && heroImg.naturalWidth > 0) {
            heroImg.classList.add('is-loaded');
        } else {
            heroImg.addEventListener('load',  function () { this.classList.add('is-loaded'); });
            heroImg.addEventListener('error', function () { this.parentElement && this.parentElement.classList.add('img-error'); });
        }
    }

    /* ── CSRF global ── */
    var meta = document.querySelector('meta[name="csrf-token"]');
    window.__CSRF__ = meta ? meta.getAttribute('content') : '';

    /* ── Wishlist AJAX ── */
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-wishlist-id]');
        if (!btn || btn.dataset.loading) return;
        e.preventDefault();

        btn.dataset.loading = '1';
        var icon = btn.querySelector('i');

        fetch('/wishlist/toggle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': window.__CSRF__,
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: JSON.stringify({ offer_id: btn.dataset.wishlistId }),
            credentials: 'same-origin',
        })
        .then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function (data) {
            var added = !!data.added;
            btn.classList.toggle('is-active', added);
            btn.setAttribute('aria-pressed', added.toString());
            if (icon) { icon.className = added ? 'fas fa-heart' : 'far fa-heart'; }
        })
        .catch(function (err) { console.warn('[Wishlist]', err); })
        .finally(function () { delete btn.dataset.loading; });
    });

    /* ── Newsletter AJAX ── */
    document.querySelectorAll('[data-newsletter]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var submit = form.querySelector('[type="submit"]');
            var emailInput = form.querySelector('[name="email"]');
            if (!emailInput || !emailInput.value.trim()) return;

            var origHTML = submit ? submit.innerHTML : '';
            if (submit) {
                submit.disabled = true;
                submit.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right:8px" aria-hidden="true"></i>Envoi…';
            }

            fetch(form.getAttribute('action') || '/newsletter/subscribe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': window.__CSRF__,
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify({ email: emailInput.value.trim() }),
                credentials: 'same-origin',
            })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success || data.message) {
                    emailInput.value = '';
                    if (submit) {
                        submit.innerHTML = '<i class="fas fa-check" style="margin-right:8px" aria-hidden="true"></i>Inscrit !';
                    }
                } else {
                    if (submit) { submit.disabled = false; submit.innerHTML = origHTML; }
                }
            })
            .catch(function () {
                if (submit) { submit.disabled = false; submit.innerHTML = origHTML; }
            });
        });
    });

})();
</script>


<?php echo $__env->make('components._chatbot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\Users\PC\Herd\discovtrip\resources\views/layouts/app.blade.php ENDPATH**/ ?>