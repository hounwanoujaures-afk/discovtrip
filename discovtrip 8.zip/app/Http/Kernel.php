<?php

namespace App\Http;

use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     * Appliqués à TOUTES les requêtes.
     */
    protected $middleware = [
        \App\Http\Middleware\TrustProxies::class,
        \Illuminate\Http\Middleware\HandleCors::class,
        \App\Http\Middleware\PreventRequestsDuringMaintenance::class,
        \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
        \App\Http\Middleware\TrimStrings::class,
        \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,

        // ── Sécurité globale ──────────────────────────────────────────
        \App\Http\Middleware\SecurityHeaders::class,   // CSP, X-Frame-Options, HSTS
        \App\Http\Middleware\SanitizeInput::class,     // Détection XSS (sans double-encodage)
        \App\Http\Middleware\ForceHttps::class,        // HTTP → HTTPS en production
        \App\Http\Middleware\IpFiltering::class,       // Blacklist IP (désactivé par défaut)
    ];

    /**
     * The application's route middleware groups.
     */
    protected $middlewareGroups = [
        'web' => [
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\Session\Middleware\StartSession::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            \App\Http\Middleware\VerifyCsrfToken::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
        ],

        'api' => [
            \Illuminate\Routing\Middleware\ThrottleRequests::class.':api',
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
            \App\Http\Middleware\AuditLog::class,
        ],
    ];

    /**
     * The application's middleware aliases.
     */
    protected $middlewareAliases = [
        'auth'             => \App\Http\Middleware\Authenticate::class,
        'auth.basic'       => \Illuminate\Auth\Middleware\AuthenticateWithBasicAuth::class,
        'auth.session'     => \Illuminate\Session\Middleware\AuthenticateSession::class,
        'cache.headers'    => \Illuminate\Http\Middleware\SetCacheHeaders::class,
        'can'              => \Illuminate\Auth\Middleware\Authorize::class,
        'guest'            => \App\Http\Middleware\RedirectIfAuthenticated::class,
        'password.confirm' => \Illuminate\Auth\Middleware\RequirePassword::class,
        'precognitive'     => \Illuminate\Foundation\Http\Middleware\HandlePrecognitiveRequests::class,
        'signed'           => \App\Http\Middleware\ValidateSignature::class,
        'throttle'         => \Illuminate\Routing\Middleware\ThrottleRequests::class,
        'verified'         => \Illuminate\Auth\Middleware\EnsureEmailIsVerified::class,

        // ── Alias custom ──────────────────────────────────────────────
        'not.banned'       => \App\Http\Middleware\EnsureUserIsNotBanned::class,
        'role'             => \App\Http\Middleware\CheckRole::class,
        'admin'            => \App\Http\Middleware\AdminMiddleware::class,
        'rate.advanced'    => \App\Http\Middleware\AdvancedRateLimiting::class,
        'force.https'      => \App\Http\Middleware\ForceHttps::class,
        'ip.filter'        => \App\Http\Middleware\IpFiltering::class,
        'audit'            => \App\Http\Middleware\AuditLog::class,
    ];
}